class Test03Shell{
public static void main(String[] ar){
System.out.println("Test uspesen …….");
}
}