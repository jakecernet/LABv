class Test05Shell{
public static void main(String[] ar){
i=33;
System.out.println("Test uspesen ……."+i);
}
}