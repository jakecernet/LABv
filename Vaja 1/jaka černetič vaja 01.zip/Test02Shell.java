class Test02Shell{
static void main(String[] args){
System.out.println("Test uspesen …….");
}
}