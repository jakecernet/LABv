class Test07Shell{
public static void main(){
System.out.println("Test uspesen …….");
}
}