class Test06Shell{
public void main(String[] ar){
System.out.println("Test uspesen …….");
}
}