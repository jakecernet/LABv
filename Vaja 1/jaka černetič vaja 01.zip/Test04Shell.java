class Test04Shell{
public static void main(String[] args){
println("Test uspesen …….");
}
}