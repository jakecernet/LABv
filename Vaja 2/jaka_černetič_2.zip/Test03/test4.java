package Test03;

public class test4 {
    public static void main(Integer[] args) {
        Float div = Float.valueOf(args[0]) / Float.valueOf(args[1]);
        System.out.println("Količnik št. " + args[0] + " in " + args[1] + " je " + div + ".");
    }
}