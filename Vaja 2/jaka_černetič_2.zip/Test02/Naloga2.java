public class Naloga2 {
  public static void main(String[] argumenti){
    System.out.println(argumenti[1]);
    int a = Integer.valueOf(argumenti[1]);
    System.out.println(a);
   }
}
