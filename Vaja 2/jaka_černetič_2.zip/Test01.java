public class Test01 {
  public static void main(String[] args) {
    String name = "Jaka";
    String surname = "Černetič";
    System.out.print(name.charAt(0));
    System.out.println(surname.charAt(0));
   }
}
