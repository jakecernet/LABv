import com.googlecode.lanterna.SGR;
import com.googlecode.lanterna.TextCharacter;
import com.googlecode.lanterna.TextColor;
import com.googlecode.lanterna.screen.Screen;
import com.googlecode.lanterna.screen.TerminalScreen;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

public class LanternaDemo {
    /** rdeč klicaj na rumenem ozadju */
    static void testChar() throws Exception {
        try (Screen screen = new DefaultTerminalFactory().createScreen()) {
            screen.startScreen();
            screen.setCharacter(5, 5,
                    new TextCharacter('!',
                            TextColor.ANSI.RED, TextColor.ANSI.YELLOW_BRIGHT,
                            SGR.UNDERLINE, SGR.BOLD));
            screen.refresh();
            Thread.sleep(5000);
        }
    }

    public static void main(String[] args) throws Exception {
        testChar();

        try (Screen screen = new DefaultTerminalFactory().createScreen()) {
            screen.startScreen();
            var text = screen.newTextGraphics();
            text.setForegroundColor(TextColor.ANSI.RED);
            text.setBackgroundColor(TextColor.ANSI.YELLOW_BRIGHT);

            text.putString(11, 19, "Hello");
            text.putString(12, 20, "World!");
            screen.refresh();
            Thread.sleep(1500);

            // text.putString(11, 15, "Hello");
            text.putString(12, 17, "World!");
            screen.refresh();
            Thread.sleep(1500);

            text.putString(11, 16, "Hello");
            // text.putString(12, 16, "World!");
            screen.refresh();
            Thread.sleep(1500);

            // text.putString(11, 15, "Hello");
            text.putString(12, 15, "World!");
            screen.refresh();
            Thread.sleep(3000);

            int w = 15, h = 16;
            while (Math.min(w, h) >= 3) { // da se še vidi vrh 2 premik pa še ena
                text.setBackgroundColor(TextColor.ANSI.BLACK);
                text.putString(11, h, "......."); // brišemo staro pozicijo ???
                text.setBackgroundColor(TextColor.ANSI.YELLOW_BRIGHT);
                h -= 2;
                text.putString(11, h, "Hello");
                text.putString(12, w, "World!");
                screen.refresh();
                Thread.sleep(700);

                text.setBackgroundColor(TextColor.ANSI.BLACK);
                text.putString(12, w, "+ + + + +");
                text.setBackgroundColor(TextColor.ANSI.YELLOW_BRIGHT);
                w -= 2;
                text.putString(11, h, "Hello");
                text.putString(12, w, "World!");
                screen.refresh();
                Thread.sleep(700);
            }

            Thread.sleep(5000);

        }
    }
}
