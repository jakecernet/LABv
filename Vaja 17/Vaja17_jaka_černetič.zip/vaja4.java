/*  
    Na osnovi sledi spreminjanja tabelarične spremenljivke tabela ugotovite, kateri algoritem je bil uporabljen
    pri urejanju.

--------------------------------------
prehod 	   tabela
-------------------------------------- 
  0 	[2,8,9,3,1,6] začetna vrednost
  1 	[1,8,9,3,2,6]
  2 	[1,2,9,3,8,6]
  3 	[1,2,3,9,8,6]
  4 	[1,2,3,6,8,9]
  5 	[1,2,3,6,8,9] končna vrednost
---------------------------------------

Uporabljen je bil bubble sort algoritem.
*/
