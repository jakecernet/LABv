/*
 * Ugotovite, kaj izpiše naslednji program (dokaz=sled+izpis).
 * public class Naloga04_03{
 * public static void main(String[] args){
 * int i=4;
 * do {
 * System.out.print("To je ");
 * System.out.print("zanka do-while ");
 * System.out.printf("številka %4d",i);
 * System.out.println();
 * i = i + 2;
 * } while ( i!=20 );
 * System.out.println(" Konec zanke. ");
 * }
 * }
 */

//program nastavi i na 4 in izpisuje "To je zanka do-while številka" in številko i, dokler i ni enako 20

// Sled izvajanja:
// ----------------
// i = 4
// izpis: "To je zanka do-while številka    4"

// i = 6
// izpis: "To je zanka do-while številka    6"

// i = 8
// izpis: "To je zanka do-while številka    8"

// i = 10
// izpis: "To je zanka do-while številka   10"

// i = 12
// izpis: "To je zanka do-while številka   12"

// i = 14
// izpis: "To je zanka do-while številka   14"

// i = 16
// izpis: "To je zanka do-while številka   16"

// i = 18
// izpis: "To je zanka do-while številka   18"

// Konec zanke.
// ----------------
